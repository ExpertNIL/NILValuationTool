export default function handler(req, res) {
  if (req.method === "POST") {
    const { talentScore, followers } = req.body;
    const baseValue = talentScore * 100;
    const socialMultiplier = followers > 50000 ? 1.2 : 1;
    const valuation = Math.round(baseValue * socialMultiplier);
    res.status(200).json({ valuation });
  } else {
    res.status(405).json({ error: "Method not allowed" });
  }
}
export default function Home() {
  return (
    <div>
      <h1>ExpertNIL Valuation Tool Backend is Live</h1>
    </div>
  );
}